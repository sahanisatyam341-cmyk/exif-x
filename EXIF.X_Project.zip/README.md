# EXIF.X — OSINT Lab

A local-first Android/WebView photo metadata viewer.

## Features
- Read common JPEG EXIF camera fields and GPS tags when they exist in the image.
- Display image dimensions, SHA-256, color palette, printable strings, and a basic ELA comparison.
- Export a JSON report and create a metadata-stripped JPEG copy.
- Privacy Lab: after an explicit checkbox, displays the current user's browser/device diagnostics locally.

## Privacy and limitations
- EXIF.X does **not** obtain GPS from the phone's live location. It can only read GPS coordinates already embedded in the selected photo.
- If the camera did not save location tags, or a messaging/editing app removed them, GPS will show as unavailable.
- Privacy Lab does not collect visitor IP addresses, does not create tracking links, and does not transmit diagnostic data to a server.
- ELA is a visual comparison aid, not proof that an image is authentic or edited.
- The app processes selected images locally in the WebView.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35 installed, then build the `app` module.

## Project structure
- `app/src/main/assets/index.html` — EXIF.X web interface
- `app/src/main/java/com/satyam/exifx/MainActivity.java` — Android WebView activity
- `app/src/main/AndroidManifest.xml` — Android manifest
- `app/build.gradle` — app build configuration
